import React from 'react';
import { useSelector } from 'react-redux';
import TodoItem from './TodoItem';

function TodoList() {
  const { tasks, filter, searchTerm } = useSelector((state) => state.todos);

  const filteredTasks = tasks
    .filter(task => {
      if (filter === 'completed') return task.completed;
      if (filter === 'pending') return !task.completed;
      return true;
    })
    .filter(task =>
      task.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

  return (
    <div className="card card-hover">
      <ul className="divide-y divide-gray-200">
        {filteredTasks.length > 0 ? (
          filteredTasks.map((task) => <TodoItem key={task.id} task={task} />)
        ) : (
          <p className="p-6 text-center text-slate-500">No tasks found.</p>
        )}
      </ul>
    </div>
  );
}

export default TodoList;


