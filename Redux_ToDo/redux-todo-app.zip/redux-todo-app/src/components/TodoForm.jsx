import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTask } from '../features/todos/todosSlice';

function TodoForm() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name.trim()) {
      dispatch(addTask(name, description));
      setName('');
      setDescription('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="card card-hover mb-6 p-5">
      <div className="flex flex-col gap-3">
        <input
          type="text"
          className="input"
          placeholder="Task name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <textarea
          className="input min-h-24"
          placeholder="Optional description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit" className="btn btn-primary w-full">Add Task</button>
      </div>
    </form>
  );
}

export default TodoForm;


