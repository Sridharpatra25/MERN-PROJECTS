import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setFilter, setSearchTerm } from '../features/todos/todosSlice';

function FilterAndSearch() {
  const dispatch = useDispatch();
  const currentFilter = useSelector((state) => state.todos.filter);

  const handleFilterChange = (filter) => {
    dispatch(setFilter(filter));
  };
  
  const handleSearchChange = (e) => {
    dispatch(setSearchTerm(e.target.value));
  };

  const getButtonClass = (filter) => {
    return `btn ${currentFilter === filter ? 'bg-blue-100 text-blue-800 ring-1 ring-inset ring-blue-300' : 'btn-ghost'}`;
  };

  return (
    <div className="card card-hover mb-6 p-4 flex flex-col sm:flex-row justify-between items-center gap-4">
      <div className="flex gap-2">
        <button onClick={() => handleFilterChange('all')} className={getButtonClass('all')}>All</button>
        <button onClick={() => handleFilterChange('completed')} className={getButtonClass('completed')}>Completed</button>
        <button onClick={() => handleFilterChange('pending')} className={getButtonClass('pending')}>Pending</button>
      </div>
      <input
        type="text"
        placeholder="Search tasks..."
        onChange={handleSearchChange}
        className="input sm:w-64"
      />
    </div>
  );
}

export default FilterAndSearch;


