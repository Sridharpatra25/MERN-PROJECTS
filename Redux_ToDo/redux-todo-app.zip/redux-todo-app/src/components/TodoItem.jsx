import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deleteTask, updateTask, toggleComplete } from '../features/todos/todosSlice';

function TodoItem({ task }) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(task.name);
  const [description, setDescription] = useState(task.description);
  const dispatch = useDispatch();

  const handleUpdate = () => {
    dispatch(updateTask({ id: task.id, name, description }));
    setIsEditing(false);
  };

  return (
    <li className="flex items-center justify-between p-4 bg-white border-b border-gray-200 hover:bg-slate-50">
      {isEditing ? (
        <div className="flex-grow">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input mb-2"
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="input"
          />
        </div>
      ) : (
        <div className="flex-grow">
          <span
            onClick={() => dispatch(toggleComplete(task.id))}
            className={`cursor-pointer ${task.completed ? 'line-through text-gray-500' : ''}`}
          >
            {task.name}
          </span>
          {task.description && (
            <p className={`text-sm text-gray-600 ${task.completed ? 'line-through' : ''}`}>
              {task.description}
            </p>
          )}
        </div>
      )}

      <div className="flex items-center gap-2 ml-4">
        {isEditing ? (
          <button onClick={handleUpdate} className="btn btn-success">💾 Save</button>
        ) : (
          <>
            <button onClick={() => dispatch(toggleComplete(task.id))} className="btn btn-ghost">
                {task.completed ? '↩️ Undo' : '✔️ Mark Complete'}
            </button>
            <button onClick={() => setIsEditing(true)} className="btn btn-warning">✏️ Edit</button>
            <button onClick={() => dispatch(deleteTask(task.id))} className="btn btn-danger">🗑️ Delete</button>
          </>
        )}
      </div>
    </li>
  );
}

export default TodoItem;


