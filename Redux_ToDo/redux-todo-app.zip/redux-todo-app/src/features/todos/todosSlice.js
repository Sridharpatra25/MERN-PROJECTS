import { createSlice, nanoid } from '@reduxjs/toolkit';

// Function to load state from localStorage
const loadState = () => {
  try {
    const serializedState = localStorage.getItem('todos');
    if (serializedState === null) {
      return undefined;
    }
    return JSON.parse(serializedState);
  } catch (err) {
    return undefined;
  }
};

const initialState = loadState() || {
  tasks: [],
  filter: 'all', // 'all', 'completed', 'pending'
  searchTerm: '',
};

export const todosSlice = createSlice({
  name: 'todos',
  initialState,
  reducers: {
    addTask: {
      reducer(state, action) {
        state.tasks.push(action.payload);
      },
      prepare(name, description) { // Handles task creation with a unique ID
        return {
          payload: {
            id: nanoid(),
            name,
            description,
            completed: false,
          },
        };
      },
    },
    deleteTask: (state, action) => {
      state.tasks = state.tasks.filter((task) => task.id !== action.payload);
    },
    updateTask: (state, action) => {
      const { id, name, description } = action.payload;
      const existingTask = state.tasks.find((task) => task.id === id);
      if (existingTask) {
        existingTask.name = name;
        existingTask.description = description;
      }
    },
    toggleComplete: (state, action) => {
      const task = state.tasks.find((task) => task.id === action.payload);
      if (task) {
        task.completed = !task.completed;
      }
    },
    setFilter: (state, action) => {
      state.filter = action.payload;
    },
    setSearchTerm: (state, action) => {
      state.searchTerm = action.payload;
    },
  },
});

// Export actions to be used in components
export const { addTask, deleteTask, updateTask, toggleComplete, setFilter, setSearchTerm } = todosSlice.actions;

// Export the reducer to be included in the store
export default todosSlice.reducer;