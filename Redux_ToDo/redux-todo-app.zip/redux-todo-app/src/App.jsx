import React from 'react';
import TodoForm from './components/TodoForm.jsx';
import TodoList from './components/TodoList.jsx';
import FilterAndSearch from './components/FilterAndSearch.jsx';

function App() {
  return (
    <div className="min-h-screen font-sans">
      <div className="container mx-auto p-4 sm:p-6 lg:p-8 max-w-3xl">
        <header className="mb-6 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-800">Redux To-Do List</h1>
          <p className="mt-1 text-slate-500">Manage your tasks efficiently</p>
        </header>
        <main>
          <TodoForm />
          <FilterAndSearch />
          <TodoList />
        </main>
      </div>
    </div>
  );
}

export default App;