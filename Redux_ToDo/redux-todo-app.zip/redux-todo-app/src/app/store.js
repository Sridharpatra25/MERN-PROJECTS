import { configureStore } from '@reduxjs/toolkit';
import todosReducer from '../features/todos/todosSlice';

// Middleware to save state to localStorage on every update
const localStorageMiddleware = store => next => action => {
  const result = next(action);
  // Sync Redux state with LocalStorage on state updates 
  localStorage.setItem('todos', JSON.stringify(store.getState().todos));
  return result;
};

export const store = configureStore({
  reducer: {
    todos: todosReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(localStorageMiddleware),
});